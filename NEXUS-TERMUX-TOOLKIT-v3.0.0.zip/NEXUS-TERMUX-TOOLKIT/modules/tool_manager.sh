#!/usr/bin/env bash

tool_manager_menu() {
  while true; do
    clear; banner
    echo "TOOL MANAGER"
    echo "────────────────────────────────────────"
    echo "1) Install a package/tool"
    echo "2) Check tool status"
    echo "3) Update package lists"
    echo "4) Show installed versions"
    echo "5) Install recommended toolkit"
    echo "0) Back"
    echo
    read -r -p "Tools> " c
    case "$c" in
      1) install_tool; pause ;;
      2) check_tool; pause ;;
      3) update_lists; pause ;;
      4) versions; pause ;;
      5) install_recommended; pause ;;
      0) return ;;
      *) pause "Invalid option." ;;
    esac
  done
}

install_tool() {
  read -r -p "Package/tool name: " t
  [[ -z "$t" ]] && return
  if is_termux; then pkg install -y "$t"
  elif is_kali && have apt; then sudo apt install -y "$t" || apt install -y "$t"
  else echo "[!] No supported package manager."; fi
}

check_tool() {
  read -r -p "Command name: " t
  if have "$t"; then echo "[+] $t: $(command -v "$t")"; else echo "[-] $t: not found"; fi
}

update_lists() {
  if is_termux; then pkg update
  elif is_kali && have apt; then sudo apt update || apt update
  else echo "[!] Unsupported environment."; fi
}

versions() {
  for t in curl nmap openssl python3 git; do
    if have "$t"; then
      echo "--- $t ---"
      "$t" --version 2>/dev/null | head -n 1 || true
    fi
  done
}

install_recommended() {
  if is_termux; then
    pkg install -y git curl nmap openssl dnsutils iproute procps python || true
  elif is_kali && have apt; then
    sudo apt install -y git curl nmap openssl dnsutils iproute2 procps python3 || \
      apt install -y git curl nmap openssl dnsutils iproute2 procps python3 || true
  else
    echo "[!] Unsupported environment."
  fi
}
