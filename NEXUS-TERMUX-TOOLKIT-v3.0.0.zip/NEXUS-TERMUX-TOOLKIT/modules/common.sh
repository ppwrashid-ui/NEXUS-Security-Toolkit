#!/usr/bin/env bash

banner() {
  cat <<'EOF'
╔══════════════════════════════════════════════════════╗
║                 N E X U S  v3.0                     ║
║             SECURITY TOOLKIT                        ║
║     Termux • Kali Linux • NetHunter                ║
╚══════════════════════════════════════════════════════╝
EOF
}

pause() {
  echo
  read -r -p "${1:-Press Enter to continue...} " _
}

timestamp() { date '+%Y-%m-%d_%H-%M-%S'; }

have() { command -v "$1" >/dev/null 2>&1; }

safe_name() {
  printf '%s' "$1" | tr -cd '[:alnum:]_.-'
}

is_termux() { [[ -n "${TERMUX_VERSION:-}" || "${PREFIX:-}" == *"/com.termux/"* ]]; }
is_kali() { [[ -r /etc/os-release ]] && grep -qi '^ID=kali' /etc/os-release 2>/dev/null; }

need_cmd() {
  if ! have "$1"; then
    echo "[!] Missing dependency: $1"
    return 1
  fi
}

authorized_notice() {
  echo
  echo "[!] Use NEXUS only on systems and networks you own or are explicitly"
  echo "    authorized to test. NEXUS performs non-destructive checks."
  echo
}

report_file() {
  local prefix="$1"
  echo "$REPORT_DIR/${prefix}_$(timestamp).txt"
}
