#!/usr/bin/env bash

system_toolbox_menu() {
  while true; do
    clear; banner
    echo "SYSTEM TOOLBOX"
    echo "────────────────────────────────────────"
    echo "1) Device Information"
    echo "2) CPU Information"
    echo "3) RAM / Memory"
    echo "4) Storage"
    echo "5) Battery"
    echo "6) Network Information"
    echo "7) Internet / DNS Test"
    echo "8) Termux Permissions"
    echo "9) Kali / NetHunter Diagnostics"
    echo "10) Process Monitor"
    echo "11) System Health Check"
    echo "12) Safe Auto Fix"
    echo "13) Generate System Report"
    echo "0) Back"
    echo
    read -r -p "System> " c
    case "$c" in
      1) device_info; pause ;;
      2) cpu_info; pause ;;
      3) memory_info; pause ;;
      4) storage_info; pause ;;
      5) battery_info; pause ;;
      6) network_info; pause ;;
      7) connectivity_test; pause ;;
      8) permissions_info; pause ;;
      9) nethunter_diagnostics; pause ;;
      10) process_info; pause ;;
      11) health_check; pause ;;
      12) safe_auto_fix; pause ;;
      13) generate_system_report; pause ;;
      0) return ;;
      *) pause "Invalid option." ;;
    esac
  done
}

device_info() {
  echo "OS: $(uname -o 2>/dev/null || echo unknown)"
  echo "Kernel: $(uname -r 2>/dev/null || echo unknown)"
  echo "Architecture: $(uname -m 2>/dev/null || echo unknown)"
  echo "Hostname: $(hostname 2>/dev/null || echo unknown)"
}

cpu_info() {
  if [[ -r /proc/cpuinfo ]]; then
    grep -m1 -E 'model name|Processor|Hardware' /proc/cpuinfo || true
    echo "CPU cores: $(grep -c '^processor' /proc/cpuinfo 2>/dev/null || echo unknown)"
  else
    echo "CPU information unavailable."
  fi
}

memory_info() {
  if have free; then free -h
  elif [[ -r /proc/meminfo ]]; then grep -E 'MemTotal|MemAvailable|SwapTotal|SwapFree' /proc/meminfo
  else echo "Memory information unavailable."; fi
}

storage_info() {
  df -h 2>/dev/null || true
}

battery_info() {
  if [[ -d /sys/class/power_supply ]]; then
    for b in /sys/class/power_supply/*; do
      [[ -d "$b" ]] || continue
      echo "--- $(basename "$b") ---"
      for f in status capacity voltage_now; do
        [[ -r "$b/$f" ]] && echo "$f: $(cat "$b/$f")"
      done
    done
  else
    echo "Battery information is not exposed by this environment."
  fi
}

connectivity_test() {
  echo "DNS:"
  if have getent; then getent hosts example.com || true
  elif have nslookup; then nslookup example.com 2>/dev/null | head -n 10
  else echo "No DNS lookup tool found."; fi
  echo
  echo "HTTPS:"
  curl -I -L --max-time 8 https://example.com 2>&1 | head -n 8 || true
}

permissions_info() {
  if is_termux; then
    echo "Termux detected."
    echo "Run 'termux-setup-storage' if shared-storage access is needed."
    echo "NEXUS does not request root or modify Android security settings."
  else
    echo "Not running inside Termux."
  fi
}

nethunter_diagnostics() {
  echo "KeX: $(command -v kex 2>/dev/null || echo not-found)"
  echo "XFCE: $(command -v xfce4-session 2>/dev/null || echo not-found)"
  echo "VNC: $(command -v vncserver 2>/dev/null || echo not-found)"
  echo "DISPLAY: ${DISPLAY:-not-set}"
  echo "DBus: $(command -v dbus-launch 2>/dev/null || echo not-found)"
}

process_info() {
  if have ps; then ps -ef 2>/dev/null | head -n 25
  else echo "ps command unavailable."; fi
}

health_check() {
  echo "=== COMMANDS ==="
  for t in curl nmap openssl ip ps; do
    have "$t" && echo "[+] $t" || echo "[-] $t"
  done
  echo
  echo "=== STORAGE ==="
  df -h 2>/dev/null | head -n 8 || true
  echo
  echo "=== MEMORY ==="
  memory_info
}

safe_auto_fix() {
  echo "[*] Safe fixes only: package metadata cleanup/repair."
  safe_package_repair
}

generate_system_report() {
  local file="$REPORT_DIR/system_$(timestamp).txt"
  {
    echo "NEXUS System Report"
    echo "Time: $(date)"
    echo
    device_info
    echo
    cpu_info
    echo
    memory_info
    echo
    storage_info
    echo
    battery_info
    echo
    network_info
    echo
    nethunter_diagnostics
  } | tee "$file"
  echo "[+] Report saved: $file"
}
