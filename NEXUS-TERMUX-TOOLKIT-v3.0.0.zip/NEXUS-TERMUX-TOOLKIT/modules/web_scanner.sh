#!/usr/bin/env bash

web_menu() {
  clear; banner
  authorized_notice
  read -r -p "Target URL (authorized only): " target
  [[ -z "$target" ]] && return
  web_scan "$target"
  pause
}

web_scan() {
  local target="$1"
  [[ "$target" != http://* && "$target" != https://* ]] && target="https://$target"
  local stamp file
  stamp="$(timestamp)"
  file="$REPORT_DIR/web_${stamp}.txt"

  echo "[*] Target: $target"
  echo "[*] Report: $file"
  {
    echo "NEXUS Web Security Report"
    echo "Time: $(date)"
    echo "Target: $target"
    echo
    echo "=== HTTP INFORMATION ==="
    curl -k -sS -L --max-time "$SCAN_TIMEOUT" -o /dev/null \
      -w 'HTTP_CODE=%{http_code}\nFINAL_URL=%{url_effective}\nSERVER=%{http_version}\n' \
      "$target" 2>&1 || true
    echo
    echo "=== RESPONSE HEADERS ==="
    curl -k -sS -I -L --max-time "$SCAN_TIMEOUT" "$target" 2>&1 || true
    echo
    echo "=== SECURITY HEADER CHECK ==="
    local headers
    headers="$(curl -k -sS -I -L --max-time "$SCAN_TIMEOUT" "$target" 2>/dev/null || true)"
    for h in Strict-Transport-Security Content-Security-Policy X-Content-Type-Options X-Frame-Options Referrer-Policy Permissions-Policy; do
      if grep -qi "^$h:" <<< "$headers"; then
        echo "[+] $h: present"
      else
        echo "[-] $h: not observed"
      fi
    done
    echo
    echo "=== TECHNOLOGY / SERVER HINTS ==="
    grep -iE '^(server|x-powered-by|via):' <<< "$headers" || echo "No common technology headers observed."
  } | tee "$file"

  if have nmap; then
    read -r -p "Run a limited top-port service check? [y/N] " ans
    if [[ "$ans" =~ ^[Yy]$ ]]; then
      local host
      host="$(printf '%s' "$target" | sed -E 's#^[a-zA-Z]+://##; s#/.*$##; s/:.*$##')"
      echo >> "$file"
      echo "=== LIMITED SERVICE CHECK ===" | tee -a "$file"
      nmap -Pn -sT -sV --top-ports "$PORT_LIMIT" --version-light "$host" 2>&1 | tee -a "$file" || true
    fi
  fi
  echo
  echo "[+] Report saved: $file"
}
