#!/usr/bin/env bash

network_menu() {
  while true; do
    clear; banner
    authorized_notice
    echo "NETWORK SCANNER"
    echo "────────────────────────────────────────"
    echo "1) Show interfaces and routes"
    echo "2) Discover local devices"
    echo "3) Scan one authorized host"
    echo "0) Back"
    echo
    read -r -p "Network> " c
    case "$c" in
      1) network_info; pause ;;
      2) discover_devices; pause ;;
      3) host_scan; pause ;;
      0) return ;;
      *) pause "Invalid option." ;;
    esac
  done
}

network_info() {
  echo "=== INTERFACES ==="
  if have ip; then ip addr 2>/dev/null || true; else echo "ip command not available."; fi
  echo
  echo "=== ROUTES ==="
  if have ip; then ip route 2>/dev/null || true; else echo "ip command not available."; fi
}

discover_devices() {
  need_cmd nmap || return
  local subnet
  subnet="$(ip route 2>/dev/null | awk '$1 ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+\/[0-9]+$/ {print $1; exit}')"
  if [[ -z "$subnet" ]]; then
    read -r -p "Enter an authorized local subnet (example 192.168.1.0/24): " subnet
  fi
  [[ -z "$subnet" ]] && return
  local file="$REPORT_DIR/network_discovery_$(timestamp).txt"
  echo "[*] Scanning: $subnet"
  nmap -sn "$subnet" 2>&1 | tee "$file" || true
  echo "[+] Report saved: $file"
}

host_scan() {
  need_cmd nmap || return
  read -r -p "Authorized host IP/hostname: " host
  [[ -z "$host" ]] && return
  local file="$REPORT_DIR/host_$(safe_name "$host")_$(timestamp).txt"
  nmap -Pn -sT -sV --top-ports "$PORT_LIMIT" --version-light "$host" 2>&1 | tee "$file" || true
  echo "[+] Report saved: $file"
}
