#!/usr/bin/env bash

config_menu() {
  while true; do
    clear; banner
    echo "CONFIGURATION"
    echo "────────────────────────────────────────"
    echo "1) Show configuration"
    echo "2) Set scan timeout"
    echo "3) Set top-port limit"
    echo "4) Reset configuration"
    echo "0) Back"
    echo
    read -r -p "Config> " c
    case "$c" in
      1) show_config; pause ;;
      2) set_timeout; pause ;;
      3) set_port_limit; pause ;;
      4) reset_config; pause ;;
      0) return ;;
      *) pause "Invalid option." ;;
    esac
  done
}

show_config() {
  echo "SCAN_TIMEOUT=$SCAN_TIMEOUT"
  echo "PORT_LIMIT=$PORT_LIMIT"
  echo "CONFIG_FILE=$CONFIG_FILE"
}

set_timeout() {
  read -r -p "Timeout seconds [1-60]: " v
  [[ "$v" =~ ^[1-9][0-9]?$|^60$ ]] || { echo "Invalid value."; return; }
  sed -i '/^SCAN_TIMEOUT=/d' "$CONFIG_FILE" 2>/dev/null || true
  echo "SCAN_TIMEOUT=$v" >> "$CONFIG_FILE"
  SCAN_TIMEOUT="$v"
}

set_port_limit() {
  read -r -p "Top ports [1-100]: " v
  [[ "$v" =~ ^[1-9][0-9]?$|^100$ ]] || { echo "Invalid value."; return; }
  sed -i '/^PORT_LIMIT=/d' "$CONFIG_FILE" 2>/dev/null || true
  echo "PORT_LIMIT=$v" >> "$CONFIG_FILE"
  PORT_LIMIT="$v"
}

reset_config() {
  cat > "$CONFIG_FILE" <<'EOF'
SCAN_TIMEOUT=10
PORT_LIMIT=20
EOF
  SCAN_TIMEOUT=10
  PORT_LIMIT=20
  echo "[+] Configuration reset."
}
