#!/usr/bin/env bash

lab_mode_menu() {
  while true; do
    clear; banner
    echo "LAB MODE"
    echo "────────────────────────────────────────"
    echo "Designed for localhost and authorized training labs."
    echo
    echo "1) Scan localhost"
    echo "2) Scan a local lab URL"
    echo "3) Show safe lab targets"
    echo "0) Back"
    echo
    read -r -p "Lab> " c
    case "$c" in
      1) web_scan "http://127.0.0.1"; pause ;;
      2) read -r -p "Lab URL: " u; [[ -n "$u" ]] && web_scan "$u"; pause ;;
      3) echo "Examples: http://127.0.0.1:8080, http://localhost:8080"; pause ;;
      0) return ;;
      *) pause "Invalid option." ;;
    esac
  done
}
