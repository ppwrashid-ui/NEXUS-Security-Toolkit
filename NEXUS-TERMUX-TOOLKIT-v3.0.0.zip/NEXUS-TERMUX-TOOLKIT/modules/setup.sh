#!/usr/bin/env bash

setup_menu() {
  while true; do
    clear; banner
    echo "SMART SETUP & REPAIR"
    echo "────────────────────────────────────────"
    echo "1) Detect environment"
    echo "2) Check dependencies"
    echo "3) Install core packages"
    echo "4) Safe package repair"
    echo "5) Run all setup checks"
    echo "0) Back"
    echo
    read -r -p "Setup> " c
    case "$c" in
      1) detect_environment; pause ;;
      2) dependency_check; pause ;;
      3) install_core_packages; pause ;;
      4) safe_package_repair; pause ;;
      5) detect_environment; dependency_check; install_core_packages; safe_package_repair; pause ;;
      0) return ;;
      *) pause "Invalid option." ;;
    esac
  done
}

detect_environment() {
  echo "[*] Environment detection"
  if is_termux; then echo "[+] Termux detected"; else echo "[-] Termux not detected"; fi
  if is_kali; then echo "[+] Kali Linux detected"; else echo "[-] Kali Linux not detected"; fi
  if [[ -x /usr/bin/kex ]]; then echo "[+] NetHunter/KeX components detected"; fi
  if [[ -x /usr/bin/xfce4-session ]]; then echo "[+] XFCE detected"; fi
  echo "[*] Architecture: $(uname -m 2>/dev/null || echo unknown)"
}

dependency_check() {
  local tools=(curl nmap awk sed grep)
  echo "[*] Dependency check"
  for t in "${tools[@]}"; do
    if have "$t"; then
      echo "[+] $t: installed"
    else
      echo "[-] $t: missing"
    fi
  done
}

install_core_packages() {
  if is_termux; then
    echo "[*] Installing core Termux packages..."
    pkg update -y || true
    pkg install -y curl nmap openssl dnsutils iproute procps coreutils || true
  elif is_kali; then
    echo "[*] Installing core Kali packages..."
    if have apt; then
      sudo apt update || apt update || true
      sudo apt install -y curl nmap openssl dnsutils iproute2 procps || true
    fi
  else
    echo "[!] Unsupported package environment."
  fi
}

safe_package_repair() {
  if is_termux; then
    echo "[*] Running safe Termux package maintenance..."
    pkg autoclean || true
    pkg clean || true
    pkg update || true
    dpkg --audit || true
  elif is_kali && have apt; then
    echo "[*] Running safe APT repair checks..."
    sudo apt --fix-broken install || apt --fix-broken install || true
    sudo dpkg --configure -a || dpkg --configure -a || true
  else
    echo "[!] No supported repair routine detected."
  fi
}
