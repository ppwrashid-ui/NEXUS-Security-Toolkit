#!/usr/bin/env bash

reports_menu() {
  while true; do
    clear; banner
    echo "REPORT CENTER"
    echo "────────────────────────────────────────"
    echo "1) List reports"
    echo "2) View latest report"
    echo "3) Open reports directory"
    echo "4) Delete old reports"
    echo "0) Back"
    echo
    read -r -p "Reports> " c
    case "$c" in
      1) list_reports; pause ;;
      2) view_latest; pause ;;
      3) echo "Reports: $REPORT_DIR"; pause ;;
      4) delete_reports; pause ;;
      0) return ;;
      *) pause "Invalid option." ;;
    esac
  done
}

list_reports() {
  find "$REPORT_DIR" -maxdepth 1 -type f -printf '%f\n' 2>/dev/null | sort || ls -1 "$REPORT_DIR"
}

view_latest() {
  local latest
  latest="$(find "$REPORT_DIR" -maxdepth 1 -type f -printf '%T@ %p\n' 2>/dev/null | sort -nr | head -n1 | cut -d' ' -f2-)"
  if [[ -n "$latest" && -f "$latest" ]]; then
    echo "=== $latest ==="
    cat "$latest"
  else
    echo "No reports found."
  fi
}

delete_reports() {
  read -r -p "Delete ALL NEXUS reports? Type DELETE to confirm: " c
  if [[ "$c" == "DELETE" ]]; then
    find "$REPORT_DIR" -maxdepth 1 -type f -delete
    echo "[+] Reports deleted."
  else
    echo "[*] Cancelled."
  fi
}
